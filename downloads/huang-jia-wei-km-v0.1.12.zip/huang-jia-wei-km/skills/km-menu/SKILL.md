---
name: km-menu
description: "黃嘉偉KM的0主選單。在已選用此外掛時，使用者輸入0、主選單、目錄、分類或C代號、詢問有哪些技能，或用I料號選技能及不確定該用哪支技能時使用；不直接在主選單內代寫貼文、企劃、海報或程式碼，選定後轉交對應工作技能執行，已在工作技能內回答選項則沿用該流程。"
metadata:
  version: "0.4.1"
---

# 0｜主選單

選單內容版本：0.4.1。協助已選用此外掛的使用者，以代號、分類或一句需求找到同外掛的工作技能。採繁體中文、手機單欄、短段落與簡潔目錄；實際工作沿用對應技能的完整指令。

## 收錄資料與可信範圍

「已核對收錄快照」是編輯外掛時確認的資料，不是執行時掃描帳號的 API。只顯示其中 registration 為「已核對」的工作技能；老師對照表只是分類依據，不是已安裝清單。初始 skills 為空。

本教師外掛標頭固定「黃嘉偉KM」；學生自己的私人KM是另一個獨立外掛，不以本選單改名或合併。不要每次開目錄讀 GitHub。看目錄、介紹、搜尋都不安裝技能、不修改快照。GitHub 改版也不自動更新學生外掛。

選定後取得同外掛 skill_slug 對應的可用 Skill 指令，再依其正式流程處理；沒有可用技能讀取或選用能力時，說明未取得工作技能，不能只憑摘要重寫流程或假裝已呼叫。圖片與影片能力以當前工具、使用者素材和帳號額度為準。

## 入口與數字優先順序

1. 單獨輸入 0、00、0000、主選單、目錄、有哪些技能：顯示主選單。正文、程式碼、檔名或資料中的 0 不作導航。返回目錄保留同對話可見的工作草稿。
2. 明確 I 代號忽略大小寫與前導零：I003、i3、0003 在明確選技能的脈絡下對應 I0003。料號至少補足四位，不截斷更長料號；排序、分類與分頁永遠不重編料號。
3. 裸數字 3 只在「選單等候選工作技能」時代表 I0003，不是畫面第 3 列。分類清單中裸數字 4 不代表 C04；選分類用中文名稱或 C 代號。
4. 工作技能正等候 A／B／C、21～24、91～93、步驟數字、數量等回答時，該技能的解讀優先。明確 I 代號仍可表示切換工作；用途不清的裸數字只補問一次。
5. 3001 僅在快照已核對它對應 daily-story-post／I0001 時作為相容入口；其他既有 3001 或 K01 不自動改號或覆蓋。

## 主選單與空清單

標頭固定使用「黃嘉偉KM」，下一行「想完成哪件事？」。按主要分類分組，以固定 I 代號排序，每筆兩行：

**I0003｜公仔表情設計**
公仔表情、動作與純色素材

這是排版示例，不代表已安裝 I0003。用粗體標題、段落和少量分隔線；不要用大表格、整段程式碼框或假按鈕呈現選單。平台文字畫面不承諾自訂宋體、金色或點按事件。

結尾固定引導：「輸入技能代號或直接說需求。找分類輸入『分類』；看全部輸入『全部』；0 回主選單。」

skills 為空時：「目前尚未加入工作技能。請到此外掛的『編輯外掛程式』，貼上老師本次提供的加入技能提示詞；完成儲存後，在新對話輸入 0。」不列老師五支為可用技能，不自行建立技能。

## 分類、分頁與返回

- 「分類／找分類」：只列有已核對工作技能的大分類，顯示 C 代號、中文名稱及筆數。明確輸入分類名稱或 C04，可直接查看該分類；完整工作需求有「圖片」等詞時先辨識任務，不誤當分類指令。
- 分類內顯示該分類名稱、技能筆數、每筆固定代號／中文名稱／一句用途。結尾：「輸入技能代號；返回回分類目錄；0 回主選單。」
- 「全部」：列此外掛已核對的所有工作技能，包含保留的自訂項目，不改用老師總庫。
- 分類與技能列表各自每頁最多八項。下一頁／上一頁保持目前分類及固定代號；到首尾清楚說明。不產生任意新項目填滿一頁。
- 單獨「返回」依目錄層級處理：分類內技能 → 分類清單 → 主選單。工作流程已接續時，沿用工作技能自己的返回規則；單獨 0 仍回主選單。
- 在分類內選到其他分類的裸數字：若該料號已收錄，先指出所屬分類與用途，提示用完整 I 代號明確切換；未收錄則說明尚未收錄。
- 已知但空的分類：「此外掛的這個分類尚未收錄技能。」附分類／全部／0。未知分類給現有分類名稱；不虛構項目。
- category_id 為 null 的已核對自訂技能，列在「待分類」下，仍可用原代號或名稱查找；不擅自另編料號。

## 名稱、需求與接續工作

中文名稱、代號、用途與 tags 都可用來找已收錄技能。明確選用一支技能或只有一支符合需求時，直接取得正式技能並接續，不再多問「是否開始」。例如「用 I0003，先讓我選模式」應依公仔技能列出 A／B／C；不只再顯示介紹。

「介紹 I0003」只說用途、需要資料與如何開始，不產圖。模糊需求最多列三個已收錄候選與不同用途，等使用者選擇。I0099 等未收錄料號清楚說明並提供分類／全部／0；不冒充可執行。快照存在但實際技能不可取得時，說明「目錄有登錄，但目前未取得對應技能，請核對外掛版本」。

在同一對話記住目錄頁、分類、頁碼及可見的工作進度；繼續任務只使用可見資料，必要時補問缺少資料。不承諾新對話能接續舊對話的草稿。

## 大分類與老師料號對照

主要分類：C01 策略；C02 文案；C03 編劇；C04 圖像；C05 影音；C06 LINE；C07 網站；C08 GPT 與 AI 工具；C09 語法；C10 專案。小分類暫為 null；日後調整分類不改 I 料號。

以下用於編輯時登錄，不能當成學生已安裝：
- I0001｜日常故事貼文助手｜daily-story-post｜C02｜三種貼文、原圖標題｜日常、故事、貼文。
- I0002｜直播企劃與開播助手｜live-stream-planning｜C05｜直播企劃、開播準備｜直播、企劃、開播。
- I0003｜公仔表情設計｜figurine-expression-design｜C04｜公仔表情、動作與純色素材｜公仔、表情、動作。
- I0004｜單圖動態影片提示詞助手｜image-to-video-prompt｜C05｜圖片動畫英文提示詞｜圖片、動畫、影片提示詞。
- I0005｜標題花字產生器｜title-lettering-generator｜C04｜繁體標題、花字與透明素材｜標題、花字、透明PNG。
- I0006｜通用團購助手｜group-buying-assistant｜C02｜通用開團、文案原圖與收單交付｜團購、商品、農產、服務、課程、收單。
- I0007｜1Shop容器HTML產生器｜one-shop-html-block｜C07｜1Shop容器HTML／CSS與必要JS｜1Shop、HTML、CSS、JavaScript、容器。
- I0008｜參考圖海報設計｜reference-poster-design｜C04｜參考圖海報、留白、花字層級與情緒配色｜海報、DM、Banner、留白、花字。
- I0009｜行銷決策顧問｜marketing-decision-advisor｜C01｜七項策略入口與26種盈利模式｜策略、行銷、賣點、引流、回購、盈利模式。
- I0010｜口播與訪談讀稿｜spoken-interview-reading｜C05｜已有成稿轉手機口播與完整訪談｜口播、訪談、逐字稿、讀稿、斷句、Hook。

## 編輯時登錄與更新

Plugin Creator 在加入／更新工作技能後，讀取同一外掛檔案，核對主檔與 slug，再合併下方快照。每筆保留 id、name、skill_slug、category_id、subcategory_id、summary、tags、source_version、registration；未知版本填 null，只有確定存在的技能標為「已核對」。對照表沒有的自訂技能保留原名稱與原代號，分類未知填 null；未確認料號不要自行發明。

保留其他已核對項目與自訂資料，此外掛名稱固定黃嘉偉KM；新版空模板不能清空舊快照。重複 id／slug 或同用途異名有疑義時先核對，不擅自覆蓋。必要欄位與格式修正可合併；不能以選單升級為由改寫其他工作技能。

同一版本中保存工作技能及選單快照後，回讀確認清單；儲存失敗不可宣稱已更新。技能已刪除時同步移除對應登錄；尚待核對者改為「待核對」並在一般目錄隱藏。第二階段 MCP 可沿用相同欄位，第一階段沒有 MCP 依賴。

## 已核對收錄快照

<!-- KM-REGISTRY-BEGIN -->
~~~yaml
menu_version: 0.4.1
plugin_display_name: 黃嘉偉KM
skills:
- id: I0001
  name: 日常故事貼文助手
  skill_slug: daily-story-post
  category_id: C02
  subcategory_id: null
  summary: 三種貼文、原圖標題
  tags:
  - 日常
  - 故事
  - 貼文
  source_version: 0.3.0
  registration: 已核對
- id: I0002
  name: 直播企劃與開播助手
  skill_slug: live-stream-planning
  category_id: C05
  subcategory_id: null
  summary: 直播企劃、開播準備
  tags:
  - 直播
  - 企劃
  - 開播
  source_version: 0.2.0
  registration: 已核對
- id: I0003
  name: 公仔表情設計
  skill_slug: figurine-expression-design
  category_id: C04
  subcategory_id: null
  summary: 公仔表情、動作與純色素材
  tags:
  - 公仔
  - 表情
  - 動作
  source_version: 0.1.1
  registration: 已核對
- id: I0004
  name: 單圖動態影片提示詞助手
  skill_slug: image-to-video-prompt
  category_id: C05
  subcategory_id: null
  summary: 圖片動畫英文提示詞
  tags:
  - 圖片
  - 動畫
  - 影片提示詞
  source_version: 0.1.0
  registration: 已核對
- id: I0005
  name: 標題花字產生器
  skill_slug: title-lettering-generator
  category_id: C04
  subcategory_id: null
  summary: 繁體標題、花字與透明素材
  tags:
  - 標題
  - 花字
  - 透明PNG
  source_version: 0.1.1
  registration: 已核對
- id: I0006
  name: 通用團購助手
  skill_slug: group-buying-assistant
  category_id: C02
  subcategory_id: null
  summary: 通用開團、文案原圖與收單交付
  tags:
  - 團購
  - 商品
  - 農產
  - 服務
  - 課程
  - 收單
  source_version: 0.1.2
  registration: 已核對
- id: I0007
  name: 1Shop容器HTML產生器
  skill_slug: one-shop-html-block
  category_id: C07
  subcategory_id: null
  summary: 1Shop容器HTML／CSS與必要JS，單區塊複製
  tags:
  - 1Shop
  - HTML
  - CSS
  - JavaScript
  - 容器
  - 網頁
  - 程式區塊
  source_version: 0.1.0
  registration: 已核對
- id: I0008
  name: 參考圖海報設計
  skill_slug: reference-poster-design
  category_id: C04
  subcategory_id: null
  summary: 參考圖海報、留白、花字層級與情緒配色
  tags:
  - 海報
  - DM
  - Banner
  - 留白
  - 花字
  - 情緒配色
  source_version: 0.1.0
  registration: 已核對
- id: I0009
  name: 行銷決策顧問
  skill_slug: marketing-decision-advisor
  category_id: C01
  subcategory_id: null
  summary: 七項策略入口：賣點、引流、首購回購、社群推薦、合作、檔期與26種盈利模式
  tags:
  - 策略
  - 行銷
  - 賣點
  - 引流
  - 回購
  - 社群
  - 合作
  - 盈利模式
  source_version: 0.2.0
  registration: 已核對
- id: I0010
  name: 口播與訪談讀稿
  skill_slug: spoken-interview-reading
  category_id: C05
  subcategory_id: null
  summary: 已有成稿轉手機口播與完整訪談，含暖身、Hook提問與三款片頭
  tags:
  - 口播
  - 訪談
  - 逐字稿
  - 讀稿
  - 斷句
  - Hook
  source_version: 0.1.3
  registration: 已核對
~~~
<!-- KM-REGISTRY-END -->

## 教師工具界線

裸0、00、0000是本主選單。I0000是老師專用安裝產生器，不列入學生工作技能。編輯時核對安裝版本與校驗值，本選單不在使用時連GitHub更新；個人修改及版本衝突先確認。

技能本文結束｜km-menu｜0.4.1
